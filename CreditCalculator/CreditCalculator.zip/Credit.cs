namespace Creditcls;

public abstract class Credit
{
    public abstract void Calculate();

    public abstract void SaveResult();
}