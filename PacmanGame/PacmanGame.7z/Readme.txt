1 - wall
2 - pacman
3 - ghost
4 - dot
5 - big dot
' ' - void
