namespace PacmanGame.GhostAlgorithm;
public class PathNode : IComparable<PathNode>
{
    public Position Position;
    public int G;
    public int H;
    public PathNode? Parent;

    public int F
    {
        get { return G + H; }
    }

    public PathNode(Position pos, int g, int h, PathNode? parent)
    {
        Position = pos;
        G = g;
        H = h;
        Parent = parent;
    }

    public int CompareTo(PathNode? other)
    {
        return F.CompareTo(other?.F);
    }
}