﻿namespace PacmanGame;
using System.Text;
internal static class Program
{
    async public static Task Main()
    {
        Console.OutputEncoding = Encoding.UTF8;
        var pacman = new Game();
        try
        {
            await pacman.GameLoad();
        }
        catch (InvalidMapException e)
        {
            Console.WriteLine(e.Message);
        }
        Console.WriteLine("Press Enter key to exit...".PadRight(Console.WindowWidth - 1));
        Console.CursorVisible = true;
        while (true)
        {
            if (Console.KeyAvailable)
            {
                var key = Console.ReadKey(true);
                if (key.Key == ConsoleKey.Enter)
                {
                    return;
                }
            }
        }
    }
}