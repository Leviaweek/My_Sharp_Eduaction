namespace PacmanGame.Properties;
public record struct Lives(int Value)
{
    public static Lives operator -- (Lives a) => new(a.Value - 1);
    public static Lives operator ++ (Lives a) => new(a.Value + 1);
    public override string ToString()
    {
        return Value.ToString();
    }
}