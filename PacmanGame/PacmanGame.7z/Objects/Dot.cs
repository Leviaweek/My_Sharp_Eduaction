namespace PacmanGame.Objects;
public class Dot: GameObject
{
    public Dot(Position location, Map mapObject) : base(location, mapObject)
    {
    }

    public override char Symbol { get; private protected set; } = '•';
}