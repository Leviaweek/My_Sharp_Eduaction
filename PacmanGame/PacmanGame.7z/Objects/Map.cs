namespace PacmanGame.Objects;

public class Map
{
    public char[,] MapText = new char[0, 0];
    public List<GameObject> MapObjects = new();
    public int Width = 0;
    public int Height = 0;
    public delegate void MoveDelegate();
    public event MoveDelegate? MoveEvent;
    public GameState State { get; private set; } = GameState.Game;
    public Pacman? PacmanPlayer;

    public void MoveAll()
    {
        MoveEvent?.Invoke();
        CheckState();
    }
    private void CheckState()
    {
        if (!MapObjects.Any(x => x is Dot))
            State = GameState.PacmanWin;
        else if (PacmanPlayer!.State == PlayerState.Dead)
            State = GameState.PacmanLose;
    }
    public void Destroy(GameObject obj)
    {
        MapObjects.Remove(obj);
    }
}