namespace PacmanGame.Objects;
public abstract class GameObject: IComparable<GameObject>
{
    public Position Location { get; set; }
    protected Map MapObject { get; init; }

    protected GameObject(Position location, Map mapObject)
    {
        Location = location;
        MapObject = mapObject;
    }
    public abstract char Symbol { get; private protected set; }

    public int CompareTo(GameObject? gameObject)
    {
        return Location.Z.CompareTo(gameObject?.Location.Z);
    }
}