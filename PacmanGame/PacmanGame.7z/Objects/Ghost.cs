namespace PacmanGame.Objects;
using System.Linq;

public class Ghost : Player
{
        public Ghost(Position location, Map mapObject) : base(location, mapObject) {}

        private protected override TimeSpan MoveInterval => TimeSpan.FromMilliseconds(280);
        public override char Symbol { get; private protected set; } = '*';

    private protected override void Death()
    {
		if (State == PlayerState.FreezeTime)
			return;
        Location = FirstPosition;
        State = PlayerState.FreezeTime;
    }

    private void CellAt(Position loc)
    {
        switch (State)
        {
            case PlayerState.Normal or PlayerState.Super:
            {
                var position = Location + loc;
                var obj = MapObject.MapObjects.Find(x => Position.ZLessEq(position, x.Location));
                switch (obj)
                {
                    case Wall wall:
                        return;
                    case Pacman pacman:
                        if (pacman.State == PlayerState.Super)
                        {
                            Death();
                            return;
                        }
                        Kill(pacman);
                        return;
                    default:
                        break;
                }
                Location = position;
				_lastMove = DateTime.Now;
                break;
            }
		}
    }

    private protected override void CheckState()
    {
        switch (State)
        {
            case PlayerState.FreezeTime:
                if (_lastMove == null)
                    _lastMove = DateTime.Now;
                if (DateTime.Now.Subtract((DateTime)_lastMove!) < _freezeTime)
                {
                    if (Symbol == '*')
                        Symbol = ' ';
                    else
                        Symbol = '*';
                    return;
                }
                State = PlayerState.Normal;
                Symbol = '*';
                break;
        }
    }

    private protected override void Update()
    {
        CheckState();
		if (State != PlayerState.FreezeTime && DateTime.Now.Subtract((DateTime)_lastMove!) < MoveInterval)
            return;
        Pathfinding pathfinding = new();
        pathfinding.CreateMap(MapObject.MapObjects, MapObject.Width, MapObject.Height);
        var path = pathfinding.FindPath(Location, MapObject.PacmanPlayer!.Location);
        if (path.Count == 0)
            return;
        Position nextStep;
        if (path.Count == 1)
            nextStep = path[0];
        else
            nextStep = path[1];
        CellAt(nextStep - Location);
        
    }
}
