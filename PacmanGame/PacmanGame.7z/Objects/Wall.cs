namespace PacmanGame.Objects;
public class Wall: GameObject
{
     public Wall(Position location, Map mapObject) : base(location, mapObject)
     {
     }

     public override char Symbol { get; private protected set; } = '#';
}