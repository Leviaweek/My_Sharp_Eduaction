namespace PacmanGame.States;

public enum GameState
{
    Game,
    PacmanWin,
    PacmanLose,
}