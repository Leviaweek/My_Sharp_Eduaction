namespace PacmanGame.States;

public enum PlayerState
{
        Normal,
        FreezeTime,
        Super,
        Dead
}