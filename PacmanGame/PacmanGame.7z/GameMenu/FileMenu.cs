namespace PacmanGame.GameMenu;
public class FileMenu
{
    public int LinePrinted = 0;
    public string ChoosePath()
    {
        string? FileName;
        string? MapPath;
        Console.WriteLine("File is in path with game?");
        LinePrinted += 1;
        Console.CursorVisible = false;
        var userChoose = true;
        bool? userContinue = null;
        while (true)
        {
            if (userChoose)
                {
                    Console.WriteLine("Yes < ");
                    Console.WriteLine("No    ");
                }
                else
                {
                    Console.WriteLine("Yes    ");
                    Console.WriteLine("No < ");
                }
                var pressedKey = Console.ReadKey();
                switch(pressedKey.Key)
                {
                    case ConsoleKey.UpArrow or ConsoleKey.DownArrow:
                        userChoose = !userChoose;
                        break;
                    case ConsoleKey.Enter:
                        userContinue = userChoose;
                        break;
                }
                if (userContinue != null)
                    break;
            Console.SetCursorPosition(0, Console.CursorTop - 2);
        }
        LinePrinted += 2;
        Console.CursorVisible = true;
        if (userContinue == true)
            MapPath = Directory.GetCurrentDirectory();
        else
        {
            Console.WriteLine("Enter path to map:");
            MapPath = Console.ReadLine();
            LinePrinted += 2;
        }
        Console.WriteLine("Enter file name:");
        FileName = Console.ReadLine();
        LinePrinted += 2;
        Console.SetCursorPosition(0, Console.CursorTop - LinePrinted);
        if (string.IsNullOrEmpty(MapPath) || string.IsNullOrEmpty(FileName))
        {
            Console.CursorVisible = true;
            Console.SetCursorPosition(0, Console.CursorTop + LinePrinted);
            throw new InvalidMapException("File not found. Exiting...");
        }
        var calculatedPath = Path.Join(MapPath, FileName);
        return calculatedPath;
    }
}