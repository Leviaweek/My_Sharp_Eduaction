namespace PacmanGame.GameMenu;
public class MapManager
{
    public Map CurrentMap = new();
    public void ReadMap(string path)
    {
        using var file = new StreamReader(path);
        int? isValidWidth = null;
        var iter = 0;
        while (true)
        {
            var text = file.ReadLine();
            if (string.IsNullOrEmpty(text))
                break;
            _ = text.Trim();
            CurrentMap.Width = text.Length;
            CurrentMap.Height++;
            if (isValidWidth == null)
                isValidWidth = CurrentMap.Width;
            else if (isValidWidth != CurrentMap.Width)
            {
                throw new InvalidMapException("Map is not valid. Exiting...");
            }
            for (var i = 0; i < text.Length; i++)
            {
                GameObject? mapObject = text[i] switch
                {
                    '1' => new Wall(new Position(i, iter, 1), CurrentMap),
                    '2' => new Pacman(new Position(i, iter, 2), CurrentMap),
                    '3' => new Ghost(new Position(i, iter, 3), CurrentMap),
                    '4' => new Dot(new Position(i, iter, 1), CurrentMap),
                    '5' => new BigDot(new Position(i, iter, 1), CurrentMap),
                    _ => null
                };
                var pacmanCount = CurrentMap.MapObjects.FindAll(x => x is Pacman).Count;
                if (pacmanCount > 1)
                    throw new InvalidMapException("Two pacmans... You read rules???");
                if (mapObject != null)
                    CurrentMap.MapObjects.Add(mapObject);
                    if (mapObject is Pacman pacman)
                        CurrentMap.PacmanPlayer = pacman;
            }
            iter++;
        }
        CurrentMap.MapObjects.Sort();
    }
    public void DrawMap()
    {
        EmptyMap();
        foreach (var mapObj in CurrentMap.MapObjects)
            CurrentMap.MapText[mapObj.Location.Y, mapObj.Location.X] = mapObj.Symbol;
        for (var i = 0; i < CurrentMap.Height; i++)
        {
            for (var j = 0; j < CurrentMap.Width; j++)
                if (j == CurrentMap.Width - 1)
                    Console.Write(CurrentMap.MapText[i, j].ToString().PadRight(System.Console.WindowWidth - j - 1));
                else
                    Console.Write(CurrentMap.MapText[i, j]);
            Console.WriteLine();
        }
    }

    private void EmptyMap()
    {
        for (var i = 0; i < CurrentMap.Height; i++)
            for (var j = 0; j < CurrentMap.Width; j++)
                CurrentMap.MapText[i, j] = ' ';
    }
    public void CreateMap()
    {
        CurrentMap.MapText = new char[CurrentMap.Height, CurrentMap.Width];
    }
}