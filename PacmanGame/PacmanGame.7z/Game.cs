namespace PacmanGame;
public class Game
{
    private readonly MapManager _mapManager = new();
    private readonly FileMenu _gameFile = new();
    private readonly Map _currentMap;
    private int _linePrinted;
    readonly CancellationTokenSource _token = new();

    public Game()
    {
        _currentMap = _mapManager.CurrentMap;
    }


    public async Task GameLoad()
    {
        Console.CancelKeyPress += new ConsoleCancelEventHandler(MyHandler);
        LoadMap();
        _ = PacmanControlsAsync(_token.Token);
        await GameLoop();
    }

    private void MyHandler(object? sender, ConsoleCancelEventArgs args)
    {
        Console.SetCursorPosition(0, Console.CursorTop + _mapManager.CurrentMap.Height);
    }

    async private Task GameLoop()
    {
        while (true)
        {
            Console.SetCursorPosition(0, Console.CursorTop - _linePrinted);
            _linePrinted = 0;
            Console.CursorVisible = false;
            _mapManager.CurrentMap.MoveAll();
            Console.WriteLine($"Lives: {_currentMap.PacmanPlayer?.MyLives.ToString()} Score: {_currentMap.PacmanPlayer?.Score.ToString()}".PadRight(Console.WindowWidth - 1));
            _linePrinted++;
            _mapManager.DrawMap();
            _linePrinted += _mapManager.CurrentMap.Height;
            switch (_currentMap.State)
            {
                case GameState.PacmanWin:
                    Console.WriteLine("You win!".PadRight(Console.WindowWidth - 1));
                    _token.Cancel();
                    return;
                case GameState.PacmanLose:
                    Console.WriteLine("You lose!".PadRight(Console.WindowWidth - 1));
                    _token.Cancel();
                    return;
            }
            await Task.Delay(1);
        }
    }


    private void LoadMap()
    {
        try
        {
            _mapManager.ReadMap(_gameFile.ChoosePath());
        }
        catch (FileNotFoundException)
        {
            throw new InvalidMapException("File not found. Exiting...");
        }
        _mapManager.CreateMap();
    }

    async private Task PacmanControlsAsync(CancellationToken cancellationToken)
    {
        while (!cancellationToken.IsCancellationRequested)
        {
            if (Console.KeyAvailable)
            {
                var pressedKey = Console.ReadKey(true);
                _currentMap.PacmanPlayer?.ChangeDirection(pressedKey.Key);
            }

            await Task.Delay(1, cancellationToken);
        }
    }
}